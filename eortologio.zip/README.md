# Eortologio

## What it does ##

The extension includes:

* a browser action with a popup including HTML
